Tool to generate custom PGF font files from *.ttf files for vitashell.

principle:
----------
  The whole characters table of the .ttf font file is converted as .pgf font format.
  Then it is merged to the default vitashell PGF font to ensure special characters coverage.

Usage:
------
 - Copy your *.ttf file(s) in this folder then run MAKE_PGF.BAT.
   It will generate a *.pgf file for each.
 - Rename your *.pgf file as "font.pgf" and past it in your vitashell theme folder.
    
Credits:
--------
  tpunix for pgftool ( https://github.com/tpunix/pgftool )
  batch script and instructions by littlebalup
